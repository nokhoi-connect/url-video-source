@echo off
setlocal
cd /d "%~dp0"
title Actualizar URL Video

if not exist ".venv\Scripts\python.exe" (
    call Instalar.bat
    exit /b %errorlevel%
)

echo Actualizando compatibilidad con sitios web...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade -r requirements.txt
echo.
if errorlevel 1 (
    echo No se pudo actualizar. Comprueba tu conexion.
) else (
    echo Actualizacion completada.
)
echo.
pause
