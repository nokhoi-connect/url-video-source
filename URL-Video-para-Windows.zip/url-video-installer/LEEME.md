# URL Video

Aplicación local para descargar vídeos públicos compatibles pegando su URL. Permite elegir la calidad, guardar vídeo en MP4 o extraer el audio en MP3, consultar los datos antes de descargar, ver el progreso y cancelar una descarga.

## Cómo abrirla

1. Haz doble clic en `Iniciar.bat`.
2. La primera vez se abrirá el instalador. Necesita conexión a internet y Python 3.10 o posterior.
3. Pega una URL, pulsa **Analizar**, elige la calidad y la carpeta.
4. Confirma que tienes permiso y pulsa **Descargar vídeo**.

Los archivos se guardan por defecto en la carpeta `Descargas` de Windows.

## Compatibilidad

La aplicación usa [yt-dlp](https://github.com/yt-dlp/yt-dlp), FFmpeg y el motor JavaScript Deno, por lo que funciona con muchos sitios de vídeo y con enlaces directos a archivos multimedia. Internet cambia con frecuencia: si un sitio deja de funcionar, cierra la app y ejecuta `Actualizar.bat`.

No puede ni intenta evitar DRM, muros de pago, controles de acceso o vídeos privados. Algunos sitios pueden exigir iniciar sesión y no funcionarán desde esta versión. Utilízala únicamente con contenido propio, de dominio público o que tengas permiso para descargar.

## Archivos incluidos

- `Iniciar.bat`: abre la aplicación e inicia la instalación la primera vez.
- `Instalar.bat`: reinstala los componentes necesarios.
- `Actualizar.bat`: actualiza la compatibilidad con sitios.
- `video_downloader.py`: código fuente de la aplicación.
- `requirements.txt`: dependencias de Python.

## Solución de problemas

- **No se encontró Python:** instala Python desde [python.org](https://www.python.org/downloads/) y activa *Add Python to PATH*.
- **El sitio ya no funciona:** ejecuta `Actualizar.bat`.
- **Vídeo protegido o privado:** no es compatible; la aplicación no evita esas protecciones.
- **Antivirus o red corporativa:** puede impedir la descarga de componentes durante la primera instalación.
