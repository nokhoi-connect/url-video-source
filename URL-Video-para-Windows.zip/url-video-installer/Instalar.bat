@echo off
setlocal
cd /d "%~dp0"
title Instalador de URL Video

where py >nul 2>&1
if errorlevel 1 (
    echo.
    echo No se encontro Python.
    echo Instala Python 3.11 o posterior desde https://www.python.org/downloads/
    echo Durante la instalacion, activa la opcion "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Creando el entorno privado de la aplicacion...
    py -3.12 -m venv .venv 2>nul
    if errorlevel 1 py -3.11 -m venv .venv 2>nul
    if errorlevel 1 py -3.10 -m venv .venv
)

if not exist ".venv\Scripts\python.exe" (
    echo No se pudo crear el entorno de Python.
    pause
    exit /b 1
)

echo Instalando los componentes necesarios...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 goto :error
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :error

echo.
echo Instalacion completada. Ya puedes abrir Iniciar.bat.
echo.
pause
exit /b 0

:error
echo.
echo La instalacion no se pudo completar. Comprueba tu conexion a internet.
echo.
pause
exit /b 1
