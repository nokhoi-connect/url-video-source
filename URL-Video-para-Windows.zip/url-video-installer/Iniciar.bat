@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\pythonw.exe" (
    echo URL Video necesita instalar sus componentes la primera vez.
    call Instalar.bat
    if errorlevel 1 exit /b 1
)

start "URL Video" ".venv\Scripts\pythonw.exe" "video_downloader.py"
