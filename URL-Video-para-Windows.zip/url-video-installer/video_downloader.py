from __future__ import annotations

import os
import queue
import re
import shutil
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from urllib.parse import urlparse

try:
    import yt_dlp
except ImportError:  # Allows the launcher to show a useful installation error.
    yt_dlp = None


APP_NAME = "URL Video"
APP_VERSION = "1.0.0"

BG = "#090E1A"
SURFACE = "#111827"
SURFACE_2 = "#182235"
SURFACE_3 = "#202C42"
TEXT = "#F7F8FC"
MUTED = "#98A5BB"
ACCENT = "#6D5DFB"
ACCENT_HOVER = "#8376FF"
CYAN = "#35D6E6"
SUCCESS = "#33D69F"
WARNING = "#FFB454"
ERROR = "#FF6B7A"
BORDER = "#27344C"

QUALITY_OPTIONS = (
    "Máxima calidad",
    "Hasta 1080p",
    "Hasta 720p",
    "Hasta 480p",
    "Solo audio · MP3",
)


class DownloadCancelled(Exception):
    pass


def validate_url(value: str) -> bool:
    """Accept normal public web URLs and reject ambiguous/non-web input."""
    try:
        parsed = urlparse(value.strip())
        return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc)
    except ValueError:
        return False


def format_duration(seconds: int | float | None) -> str:
    if seconds is None:
        return "Duración desconocida"
    try:
        total = max(0, int(seconds))
    except (TypeError, ValueError):
        return "Duración desconocida"
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours}:{minutes:02d}:{secs:02d}" if hours else f"{minutes}:{secs:02d}"


def format_bytes(value: int | float | None) -> str:
    if not value:
        return "—"
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return "—"


def format_selector(quality: str) -> str:
    """Prefer MP4/M4A while retaining a broad fallback for compatible sites."""
    if quality == "Solo audio · MP3":
        return "ba/b"

    height = {
        "Hasta 1080p": "1080",
        "Hasta 720p": "720",
        "Hasta 480p": "480",
    }.get(quality)

    limit = f"[height<=?{height}]" if height else ""
    return (
        f"bv*{limit}[ext=mp4]+ba[ext=m4a]/"
        f"b{limit}[ext=mp4]/"
        f"bv*{limit}+ba/"
        f"b{limit}/b"
    )


def default_download_folder() -> Path:
    downloads = Path.home() / "Downloads"
    return downloads if downloads.exists() else Path.home()


def resolve_ffmpeg() -> str | None:
    system_ffmpeg = shutil.which("ffmpeg")
    if system_ffmpeg:
        return system_ffmpeg
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except (ImportError, RuntimeError, OSError):
        return None


def resolve_deno() -> str | None:
    """Find the JavaScript runtime installed beside the app's Python."""
    candidates = (
        shutil.which("deno"),
        str(Path(sys.executable).resolve().parent / "deno.exe"),
    )
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return candidate
    return None


def clean_error(error: Exception) -> str:
    message = re.sub(r"(?i)^error:\s*", "", str(error)).strip()
    low = message.lower()
    if "unsupported url" in low:
        return "Este sitio o enlace todavía no es compatible."
    if "drm" in low:
        return "El vídeo está protegido con DRM y no se puede descargar."
    if "private video" in low or "login" in low or "sign in" in low:
        return "El vídeo requiere iniciar sesión o no es público."
    if "video unavailable" in low:
        return "El vídeo no está disponible."
    if "ffmpeg" in low:
        return "No se pudo procesar el archivo con FFmpeg. Reinstala la aplicación."
    if "unable to download" in low or "network" in low or "timed out" in low:
        return "No se pudo conectar con el sitio. Comprueba tu conexión e inténtalo de nuevo."
    return message[:340] or "Ha ocurrido un error inesperado."


class QueueLogger:
    def __init__(self, event_queue: queue.Queue):
        self.event_queue = event_queue

    def debug(self, message: str) -> None:
        if message.startswith("[download] Destination:"):
            self.event_queue.put(("status", "Preparando el archivo…"))

    def info(self, message: str) -> None:
        return

    def warning(self, message: str) -> None:
        self.event_queue.put(("notice", message))

    def error(self, message: str) -> None:
        return


class VideoDownloaderApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.events: queue.Queue = queue.Queue()
        self.cancel_event = threading.Event()
        self.worker: threading.Thread | None = None
        self.metadata: dict | None = None

        self.url_var = tk.StringVar()
        self.quality_var = tk.StringVar(value=QUALITY_OPTIONS[1])
        self.folder_var = tk.StringVar(value=str(default_download_folder()))
        self.rights_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="Listo para analizar un enlace")
        self.detail_var = tk.StringVar(value="Pega una URL pública para empezar")
        self.progress_var = tk.DoubleVar(value=0)

        self._configure_window()
        self._configure_styles()
        self._build_ui()
        self.url_var.trace_add("write", self._on_url_changed)
        self.rights_var.trace_add("write", self._refresh_download_state)
        self.root.after(100, self._poll_events)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _configure_window(self) -> None:
        self.root.title(f"{APP_NAME} · Descargador")
        self.root.geometry("960x760")
        self.root.minsize(820, 680)
        self.root.configure(bg=BG)
        self.root.option_add("*Font", "{Segoe UI} 10")

    def _configure_styles(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")

        style.configure(
            "Accent.TButton",
            background=ACCENT,
            foreground=TEXT,
            bordercolor=ACCENT,
            lightcolor=ACCENT,
            darkcolor=ACCENT,
            relief="flat",
            padding=(22, 13),
            font=("Segoe UI Semibold", 10),
        )
        style.map(
            "Accent.TButton",
            background=[("disabled", "#3A4157"), ("active", ACCENT_HOVER)],
            foreground=[("disabled", "#7C879A"), ("active", TEXT)],
        )
        style.configure(
            "Secondary.TButton",
            background=SURFACE_3,
            foreground=TEXT,
            bordercolor=BORDER,
            lightcolor=SURFACE_3,
            darkcolor=SURFACE_3,
            relief="flat",
            padding=(17, 11),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "Secondary.TButton",
            background=[("disabled", "#20283A"), ("active", "#2B3953")],
            foreground=[("disabled", "#657187"), ("active", TEXT)],
        )
        style.configure(
            "Danger.TButton",
            background="#33202B",
            foreground="#FF92A0",
            bordercolor="#5B2B3A",
            relief="flat",
            padding=(14, 9),
            font=("Segoe UI Semibold", 9),
        )
        style.map("Danger.TButton", background=[("active", "#472635")])
        style.configure(
            "Dark.TCombobox",
            fieldbackground=SURFACE_2,
            background=SURFACE_3,
            foreground=TEXT,
            arrowcolor=MUTED,
            bordercolor=BORDER,
            lightcolor=BORDER,
            darkcolor=BORDER,
            padding=9,
        )
        style.map(
            "Dark.TCombobox",
            fieldbackground=[("readonly", SURFACE_2)],
            foreground=[("readonly", TEXT)],
            selectbackground=[("readonly", SURFACE_2)],
            selectforeground=[("readonly", TEXT)],
        )
        style.configure(
            "Download.Horizontal.TProgressbar",
            troughcolor=SURFACE_3,
            background=CYAN,
            bordercolor=SURFACE_3,
            lightcolor=CYAN,
            darkcolor=CYAN,
            thickness=9,
        )
        style.configure(
            "Rights.TCheckbutton",
            background=SURFACE,
            foreground=MUTED,
            indicatorcolor=SURFACE_3,
            indicatorrelief="flat",
            padding=0,
        )
        style.map(
            "Rights.TCheckbutton",
            background=[("active", SURFACE)],
            foreground=[("active", TEXT)],
            indicatorcolor=[("selected", ACCENT)],
        )

    def _build_ui(self) -> None:
        outer = tk.Frame(self.root, bg=BG)
        outer.pack(fill="both", expand=True)
        outer.grid_columnconfigure(0, weight=1)
        outer.grid_rowconfigure(2, weight=1)

        header = tk.Frame(outer, bg=BG)
        header.grid(row=0, column=0, sticky="ew", padx=48, pady=(30, 0))
        header.grid_columnconfigure(1, weight=1)

        logo = tk.Canvas(header, width=36, height=36, bg=BG, highlightthickness=0)
        logo.grid(row=0, column=0, rowspan=2, padx=(0, 11))
        logo.create_oval(2, 2, 34, 34, fill=ACCENT, outline="")
        logo.create_polygon(15, 11, 15, 25, 26, 18, fill=TEXT, outline="")
        tk.Label(
            header,
            text="URL VIDEO",
            bg=BG,
            fg=TEXT,
            font=("Segoe UI Semibold", 11),
        ).grid(row=0, column=1, sticky="sw")
        tk.Label(
            header,
            text=f"v{APP_VERSION}",
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 8),
        ).grid(row=1, column=1, sticky="nw")
        tk.Label(
            header,
            text="PRIVADO · LOCAL · SIN CUENTAS",
            bg=BG,
            fg=CYAN,
            font=("Segoe UI Semibold", 8),
        ).grid(row=0, column=2, rowspan=2, sticky="e")

        hero = tk.Frame(outer, bg=BG)
        hero.grid(row=1, column=0, sticky="ew", padx=48, pady=(27, 20))
        tk.Label(
            hero,
            text="Pega el enlace. Quédate con el vídeo.",
            bg=BG,
            fg=TEXT,
            font=("Segoe UI Semibold", 25),
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            hero,
            text="Descarga vídeos públicos compatibles o extrae el audio en MP3.",
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 11),
            anchor="w",
        ).pack(fill="x", pady=(7, 0))

        card = tk.Frame(outer, bg=SURFACE, highlightthickness=1, highlightbackground=BORDER)
        card.grid(row=2, column=0, sticky="nsew", padx=48, pady=(0, 25))
        card.grid_columnconfigure(0, weight=1)
        card.grid_rowconfigure(5, weight=1)

        url_section = tk.Frame(card, bg=SURFACE)
        url_section.grid(row=0, column=0, sticky="ew", padx=26, pady=(23, 13))
        url_section.grid_columnconfigure(0, weight=1)
        self._field_label(url_section, "URL DEL VÍDEO").grid(row=0, column=0, sticky="w", columnspan=2)

        entry_shell = tk.Frame(url_section, bg=SURFACE_2, highlightthickness=1, highlightbackground=BORDER)
        entry_shell.grid(row=1, column=0, sticky="ew", pady=(7, 0), padx=(0, 10))
        entry_shell.grid_columnconfigure(0, weight=1)
        self.url_entry = tk.Entry(
            entry_shell,
            textvariable=self.url_var,
            bg=SURFACE_2,
            fg=TEXT,
            insertbackground=TEXT,
            selectbackground=ACCENT,
            relief="flat",
            borderwidth=0,
            font=("Segoe UI", 11),
        )
        self.url_entry.grid(row=0, column=0, sticky="ew", padx=(14, 6), pady=12)
        self.url_entry.bind("<Return>", lambda _event: self._analyze())
        tk.Button(
            entry_shell,
            text="PEGAR",
            command=self._paste,
            bg=SURFACE_2,
            fg=CYAN,
            activebackground=SURFACE_3,
            activeforeground=TEXT,
            relief="flat",
            borderwidth=0,
            cursor="hand2",
            font=("Segoe UI Semibold", 8),
            padx=12,
        ).grid(row=0, column=1, sticky="ns", padx=(0, 4), pady=4)
        self.analyze_button = ttk.Button(
            url_section,
            text="ANALIZAR →",
            style="Secondary.TButton",
            command=self._analyze,
        )
        self.analyze_button.grid(row=1, column=1, sticky="e", pady=(7, 0))

        self.preview = tk.Frame(card, bg=SURFACE_2, highlightthickness=1, highlightbackground=BORDER)
        self.preview.grid(row=1, column=0, sticky="ew", padx=26, pady=(0, 13))
        self.preview.grid_columnconfigure(0, weight=1)
        self.preview_title = tk.Label(
            self.preview,
            text="Aún no hay ningún vídeo analizado",
            bg=SURFACE_2,
            fg=TEXT,
            font=("Segoe UI Semibold", 11),
            anchor="w",
        )
        self.preview_title.grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 2))
        self.preview_meta = tk.Label(
            self.preview,
            text="Comprobaremos el título, la duración y el sitio antes de descargar.",
            bg=SURFACE_2,
            fg=MUTED,
            font=("Segoe UI", 9),
            anchor="w",
        )
        self.preview_meta.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 12))
        self.preview_badge = tk.Label(
            self.preview,
            text="PENDIENTE",
            bg=SURFACE_3,
            fg=MUTED,
            font=("Segoe UI Semibold", 8),
            padx=10,
            pady=5,
        )
        self.preview_badge.grid(row=0, column=1, rowspan=2, padx=14)

        options = tk.Frame(card, bg=SURFACE)
        options.grid(row=2, column=0, sticky="ew", padx=26, pady=(0, 13))
        options.grid_columnconfigure(0, weight=1)
        options.grid_columnconfigure(1, weight=1)
        self._field_label(options, "CALIDAD").grid(row=0, column=0, sticky="w")
        self._field_label(options, "CARPETA DE DESTINO").grid(row=0, column=1, sticky="w", padx=(14, 0))

        self.quality_combo = ttk.Combobox(
            options,
            textvariable=self.quality_var,
            values=QUALITY_OPTIONS,
            state="readonly",
            style="Dark.TCombobox",
            font=("Segoe UI", 10),
        )
        self.quality_combo.grid(row=1, column=0, sticky="ew", pady=(7, 0))
        self.quality_combo.bind("<<ComboboxSelected>>", self._on_quality_changed)

        folder_shell = tk.Frame(options, bg=SURFACE_2, highlightthickness=1, highlightbackground=BORDER)
        folder_shell.grid(row=1, column=1, sticky="ew", padx=(14, 0), pady=(7, 0))
        folder_shell.grid_columnconfigure(0, weight=1)
        self.folder_entry = tk.Entry(
            folder_shell,
            textvariable=self.folder_var,
            bg=SURFACE_2,
            fg=TEXT,
            insertbackground=TEXT,
            selectbackground=ACCENT,
            relief="flat",
            borderwidth=0,
            font=("Segoe UI", 9),
        )
        self.folder_entry.grid(row=0, column=0, sticky="ew", padx=(12, 5), pady=10)
        tk.Button(
            folder_shell,
            text="ELEGIR",
            command=self._choose_folder,
            bg=SURFACE_2,
            fg=CYAN,
            activebackground=SURFACE_3,
            activeforeground=TEXT,
            relief="flat",
            borderwidth=0,
            cursor="hand2",
            font=("Segoe UI Semibold", 8),
            padx=10,
        ).grid(row=0, column=1, sticky="ns", padx=(0, 4), pady=4)

        consent = tk.Frame(card, bg=SURFACE)
        consent.grid(row=3, column=0, sticky="ew", padx=26, pady=(0, 12))
        ttk.Checkbutton(
            consent,
            variable=self.rights_var,
            text="Confirmo que tengo permiso para descargar este contenido.",
            style="Rights.TCheckbutton",
        ).pack(side="left")

        action_row = tk.Frame(card, bg=SURFACE)
        action_row.grid(row=4, column=0, sticky="ew", padx=26, pady=(0, 14))
        action_row.grid_columnconfigure(0, weight=1)
        self.download_button = ttk.Button(
            action_row,
            text="DESCARGAR VÍDEO  ↓",
            style="Accent.TButton",
            command=self._download,
            state="disabled",
        )
        self.download_button.grid(row=0, column=0, sticky="ew")
        self.cancel_button = ttk.Button(
            action_row,
            text="CANCELAR",
            style="Danger.TButton",
            command=self._cancel,
            state="disabled",
        )
        self.cancel_button.grid(row=0, column=1, sticky="e", padx=(10, 0))

        progress_panel = tk.Frame(card, bg=SURFACE_2)
        progress_panel.grid(row=5, column=0, sticky="nsew", padx=26, pady=(0, 22))
        progress_panel.grid_columnconfigure(0, weight=1)
        tk.Label(
            progress_panel,
            textvariable=self.status_var,
            bg=SURFACE_2,
            fg=TEXT,
            font=("Segoe UI Semibold", 10),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 2))
        self.percent_label = tk.Label(
            progress_panel,
            text="0%",
            bg=SURFACE_2,
            fg=CYAN,
            font=("Segoe UI Semibold", 10),
        )
        self.percent_label.grid(row=0, column=1, padx=16, pady=(12, 2))
        tk.Label(
            progress_panel,
            textvariable=self.detail_var,
            bg=SURFACE_2,
            fg=MUTED,
            font=("Segoe UI", 9),
            anchor="w",
        ).grid(row=1, column=0, columnspan=2, sticky="ew", padx=16)
        ttk.Progressbar(
            progress_panel,
            variable=self.progress_var,
            maximum=100,
            style="Download.Horizontal.TProgressbar",
        ).grid(row=2, column=0, columnspan=2, sticky="ew", padx=16, pady=(10, 14))

        tk.Label(
            outer,
            text="Compatible con muchos sitios públicos y enlaces directos · No evita DRM, pagos ni controles de acceso",
            bg=BG,
            fg="#68758B",
            font=("Segoe UI", 8),
        ).grid(row=3, column=0, pady=(0, 18))

        self.url_entry.focus_set()

    @staticmethod
    def _field_label(parent: tk.Widget, text: str) -> tk.Label:
        return tk.Label(
            parent,
            text=text,
            bg=SURFACE,
            fg=MUTED,
            font=("Segoe UI Semibold", 8),
        )

    def _paste(self) -> None:
        try:
            value = self.root.clipboard_get().strip()
        except tk.TclError:
            value = ""
        if value:
            self.url_var.set(value)
            self.url_entry.icursor("end")
            self._analyze()

    def _choose_folder(self) -> None:
        selected = filedialog.askdirectory(
            title="Selecciona la carpeta de destino",
            initialdir=self.folder_var.get() or str(default_download_folder()),
        )
        if selected:
            self.folder_var.set(selected)

    def _on_url_changed(self, *_args) -> None:
        if self.worker and self.worker.is_alive():
            return
        self.metadata = None
        self.preview_title.configure(text="Aún no hay ningún vídeo analizado")
        self.preview_meta.configure(text="Pulsa Analizar para comprobar el enlace.")
        self.preview_badge.configure(text="PENDIENTE", fg=MUTED, bg=SURFACE_3)
        self._refresh_download_state()

    def _refresh_download_state(self, *_args) -> None:
        busy = bool(self.worker and self.worker.is_alive())
        can_download = bool(self.metadata) and self.rights_var.get() and not busy
        self.download_button.configure(state="normal" if can_download else "disabled")
        self.analyze_button.configure(state="disabled" if busy else "normal")

    def _on_quality_changed(self, _event=None) -> None:
        noun = "AUDIO" if self.quality_var.get() == "Solo audio · MP3" else "VÍDEO"
        self.download_button.configure(text=f"DESCARGAR {noun}  ↓")

    def _set_progress(self, percent: float, status: str, detail: str) -> None:
        value = max(0.0, min(100.0, percent))
        self.progress_var.set(value)
        self.percent_label.configure(text=f"{value:.0f}%")
        self.status_var.set(status)
        self.detail_var.set(detail)

    def _analyze(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        url = self.url_var.get().strip()
        if not validate_url(url):
            messagebox.showwarning(APP_NAME, "Pega una URL válida que empiece por http:// o https://")
            self.url_entry.focus_set()
            return
        if yt_dlp is None:
            messagebox.showerror(APP_NAME, "Faltan componentes. Ejecuta Instalar.bat y vuelve a abrir la app.")
            return

        self.metadata = None
        self._set_progress(8, "Analizando el enlace…", "Consultando la información del vídeo")
        self.preview_title.configure(text="Buscando información…")
        self.preview_meta.configure(text="Esto suele tardar unos segundos.")
        self.preview_badge.configure(text="ANALIZANDO", fg=WARNING, bg="#332A20")
        self.worker = threading.Thread(target=self._analyze_worker, args=(url,), daemon=True)
        self.worker.start()
        self._refresh_download_state()

    def _base_options(self) -> dict:
        options = {
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "windowsfilenames": True,
            "logger": QueueLogger(self.events),
            "socket_timeout": 20,
            "retries": 5,
            "fragment_retries": 5,
        }
        ffmpeg = resolve_ffmpeg()
        if ffmpeg:
            options["ffmpeg_location"] = ffmpeg
        deno = resolve_deno()
        if deno:
            options["js_runtimes"] = {"deno": {"path": deno}}
        return options

    def _analyze_worker(self, url: str) -> None:
        try:
            options = self._base_options()
            options.update({"skip_download": True, "extract_flat": False})
            with yt_dlp.YoutubeDL(options) as downloader:
                info = downloader.extract_info(url, download=False)
                if info and info.get("_type") in {"playlist", "multi_video"}:
                    entries = [entry for entry in info.get("entries", []) if entry]
                    if entries:
                        info = entries[0]
                if not info:
                    raise RuntimeError("No se encontró información del vídeo.")
            summary = {
                "title": info.get("title") or "Vídeo sin título",
                "duration": info.get("duration"),
                "extractor": info.get("extractor_key") or info.get("extractor") or "Sitio web",
                "uploader": info.get("uploader") or info.get("channel") or "Autor desconocido",
                "webpage_url": info.get("webpage_url") or url,
                "live_status": info.get("live_status"),
            }
            self.events.put(("analysis_ok", summary))
        except Exception as error:
            self.events.put(("analysis_error", clean_error(error)))

    def _download(self) -> None:
        if not self.metadata or (self.worker and self.worker.is_alive()):
            return
        if not self.rights_var.get():
            messagebox.showwarning(APP_NAME, "Confirma que tienes permiso para descargar el contenido.")
            return

        folder_text = self.folder_var.get().strip()
        if not folder_text:
            messagebox.showwarning(APP_NAME, "Selecciona una carpeta de destino.")
            return
        folder = Path(folder_text).expanduser()
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            messagebox.showerror(APP_NAME, f"No se puede usar esa carpeta:\n{error}")
            return

        self.cancel_event.clear()
        self._set_progress(0, "Iniciando descarga…", self.metadata.get("title", "Vídeo"))
        self.cancel_button.configure(state="normal")
        self.worker = threading.Thread(
            target=self._download_worker,
            args=(self.metadata["webpage_url"], folder, self.quality_var.get()),
            daemon=True,
        )
        self.worker.start()
        self._refresh_download_state()

    def _download_worker(self, url: str, folder: Path, quality: str) -> None:
        def progress_hook(data: dict) -> None:
            if self.cancel_event.is_set():
                raise DownloadCancelled("Descarga cancelada")
            status = data.get("status")
            if status == "downloading":
                downloaded = data.get("downloaded_bytes") or 0
                total = data.get("total_bytes") or data.get("total_bytes_estimate") or 0
                percent = (downloaded / total * 100) if total else 0
                speed = format_bytes(data.get("speed"))
                eta = data.get("eta")
                eta_text = f" · faltan {format_duration(eta)}" if eta is not None else ""
                detail = f"{format_bytes(downloaded)} de {format_bytes(total)} · {speed}/s{eta_text}"
                self.events.put(("progress", percent, "Descargando…", detail))
            elif status == "finished":
                self.events.put(("progress", 96, "Procesando…", "Uniendo vídeo y audio; ya casi está"))

        try:
            options = self._base_options()
            options.update(
                {
                    "format": format_selector(quality),
                    "outtmpl": str(folder / "%(title).180B [%(id)s].%(ext)s"),
                    "progress_hooks": [progress_hook],
                    "continuedl": True,
                    "overwrites": False,
                    "concurrent_fragment_downloads": 4,
                }
            )
            if quality == "Solo audio · MP3":
                options["postprocessors"] = [
                    {
                        "key": "FFmpegExtractAudio",
                        "preferredcodec": "mp3",
                        "preferredquality": "192",
                    }
                ]
            else:
                options["merge_output_format"] = "mp4"

            with yt_dlp.YoutubeDL(options) as downloader:
                downloader.download([url])
            if self.cancel_event.is_set():
                raise DownloadCancelled("Descarga cancelada")
            self.events.put(("download_ok", str(folder)))
        except DownloadCancelled:
            self.events.put(("download_cancelled",))
        except Exception as error:
            if self.cancel_event.is_set():
                self.events.put(("download_cancelled",))
            else:
                self.events.put(("download_error", clean_error(error)))

    def _cancel(self) -> None:
        self.cancel_event.set()
        self.cancel_button.configure(state="disabled")
        self.status_var.set("Cancelando…")
        self.detail_var.set("La descarga se detendrá de forma segura")

    def _poll_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "analysis_ok":
                    data = event[1]
                    self.metadata = data
                    title = data["title"]
                    if len(title) > 88:
                        title = title[:85] + "…"
                    self.preview_title.configure(text=title)
                    author = data["uploader"]
                    if len(author) > 45:
                        author = author[:42] + "…"
                    self.preview_meta.configure(
                        text=f"{data['extractor']}  ·  {format_duration(data['duration'])}  ·  {author}"
                    )
                    badge_text = "DIRECTO" if data.get("live_status") == "is_live" else "LISTO"
                    self.preview_badge.configure(text=badge_text, fg=SUCCESS, bg="#17352F")
                    self._set_progress(0, "Vídeo listo", "Elige calidad y confirma que tienes permiso")
                    self.worker = None
                    self._refresh_download_state()
                elif kind == "analysis_error":
                    self.metadata = None
                    self.preview_title.configure(text="No se pudo analizar el enlace")
                    self.preview_meta.configure(text=event[1])
                    self.preview_badge.configure(text="ERROR", fg=ERROR, bg="#3B202A")
                    self._set_progress(0, "Enlace no disponible", event[1])
                    self.worker = None
                    self._refresh_download_state()
                elif kind == "progress":
                    self._set_progress(event[1], event[2], event[3])
                elif kind == "status":
                    self.status_var.set(event[1])
                elif kind == "notice":
                    self.detail_var.set(event[1][:180])
                elif kind == "download_ok":
                    folder = event[1]
                    self._set_progress(100, "Descarga completada", f"Guardado en {folder}")
                    self.cancel_button.configure(state="disabled")
                    self.worker = None
                    self._refresh_download_state()
                    if messagebox.askyesno(APP_NAME, "La descarga ha terminado. ¿Quieres abrir la carpeta?"):
                        self._open_folder(folder)
                elif kind == "download_cancelled":
                    self._set_progress(0, "Descarga cancelada", "Puedes volver a intentarlo cuando quieras")
                    self.cancel_button.configure(state="disabled")
                    self.worker = None
                    self._refresh_download_state()
                elif kind == "download_error":
                    self._set_progress(0, "No se pudo descargar", event[1])
                    self.cancel_button.configure(state="disabled")
                    self.worker = None
                    self._refresh_download_state()
                    messagebox.showerror(APP_NAME, event[1])
        except queue.Empty:
            pass
        self.root.after(100, self._poll_events)

    @staticmethod
    def _open_folder(folder: str) -> None:
        try:
            os.startfile(folder)  # type: ignore[attr-defined]
        except OSError:
            pass

    def _on_close(self) -> None:
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno(APP_NAME, "Hay una tarea en curso. ¿Quieres cerrar la aplicación?"):
                return
            self.cancel_event.set()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    VideoDownloaderApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
