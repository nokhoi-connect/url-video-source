@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\pythonw.exe" (
    where py >nul 2>&1
    if errorlevel 1 (
        powershell -NoProfile -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('Para abrir URL Video necesitas instalar Python. Se abrirá la página oficial de Python. Tras instalarlo, vuelve a abrir este archivo.','URL Video', 'OK', 'Information')" >nul 2>&1
        start "" "https://www.python.org/downloads/windows/"
        exit /b 1
    )
    echo URL Video necesita preparar sus componentes la primera vez.
    call Instalar.bat
    if errorlevel 1 exit /b 1
)

start "URL Video" ".venv\Scripts\pythonw.exe" "video_downloader.py"
